# 酒店预订系统 · 实验三实现（code/）

Python 3.12 + Tkinter + SQLite，零第三方运行期依赖；开发期只用 pylint / coverage（`requirements-dev.txt`）。

## 入口

```powershell
python run.py                       # 用 code/data/app.db；缺库时自动建表 + 写种子
python run.py --db data/demo.db     # 指定库文件
```

演示账号（种子数据，密码均为 `Passw0rd!`）：

| 手机号 | 角色 | 能做什么 |
|---|---|---|
| 13800000000 | 平台管理员 | 酒店审核、跨店查看、任意店库存与报表 |
| 13800000001 | 顾客 | 搜索、下单、取消、改期、我的订单 |
| 13800000002 / 13800000003 | 酒店店长 | 本店订单台、库存与房价、对账、报表 |

## 目录

| 目录 | 内容 |
|---|---|
| `app/domain/` | 实体、状态机（8 条允许边 / 5 条禁止边）、计价、库存规则、仓储**接口** |
| `app/application/` | 应用服务：下单/取消/改期、履约扫描、报表、对账、账号、平台审核 |
| `app/infrastructure/db/` | 12 表 DDL 与迁移、连接与事务封装、各仓储的 SQLite 实现、种子 |
| `app/ui/` | Tkinter 十屏界面（只调应用服务，不写 SQL） |
| `tests/` | 152 条用例（域规则、事务、并发、幂等、越权、履约、报表、界面链路） |
| `tools/` | `init_db` / `migrate` / `scan_once` / `reconcile_report` / `count_loc` / `check_uml_sync` / `check_source_rules` / `ui_smoke` / `ui_chain` / `concurrency_probe` |
| `docs/` | 证据 `evidence/`、追溯表 `uml_map.md`、LOC `loc.csv`、截图 `screenshots/`、报告素材 `report_materials/` |
| `config/settings.json` | 数据库路径、超时阈值、no-show 截止时刻、时区、种子规模 |

## 复跑

```powershell
python -m unittest discover -s code/tests -t code
python -m pylint code/app --rcfile=code/.pylintrc
python code/tools/count_loc.py --root code/app
python code/tools/check_uml_sync.py --puml ../exp2/UML/UML类图.puml --app code/app
python code/tools/ui_smoke.py
python code/tools/concurrency_probe.py --threads 200 --rooms 1
```
